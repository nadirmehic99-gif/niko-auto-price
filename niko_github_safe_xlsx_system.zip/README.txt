Niko Auto Core USA - GitHub Safe XLSX System

This protects your market information.

FILES:

1. customer_website/index.html
   - Upload this to GitHub Pages.
   - Customers use this page to search serial numbers.
   - It reads customer_prices.xlsx only.

2. private_admin_converter/admin-converter.html
   - Keep this private for yourself.
   - Upload your full master Excel here.
   - It creates customer_prices.xlsx with only Code + Price.
   - No market, no formulas, no Pt/Pd/Rh, no merge.

DAILY WORKFLOW:

1. Open your full Live_Market_Price.xlsx.
2. Update your market/prices.
3. Open private_admin_converter/admin-converter.html.
4. Password: niko123
5. Upload your full Excel.
6. Click Create customer_prices.xlsx.
7. Click Download customer_prices.xlsx.
8. In GitHub, replace the old customer_prices.xlsx in the same folder as customer index.html.
9. Customers refresh and search latest prices.

IMPORTANT:

Do not upload your full master Excel to public GitHub.
Upload only customer_prices.xlsx.
